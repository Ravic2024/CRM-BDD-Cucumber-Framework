package com.qa.steps;

import com.qa.engine.ExcelReaderandwrite;
import com.qa.engine.ProjectBase;
import io.cucumber.java.*;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Hooks extends ProjectBase {

    public static PrintStream printStream;
    private WebDriver driver;
    private static Scenario scenario;
    private ExecutorService executorService = Executors.newFixedThreadPool(2);
    private ExcelReaderandwrite readerWorker;
    @Before
    public void setup() {
        if (readerWorker == null) {
            readerWorker = new ExcelReaderandwrite(); // Create instance
            executorService.submit(readerWorker);  // Submit as a Runnable instead of calling start()
        }
    }
    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }
    public static Scenario getScenario() {
        return scenario;  // Return the static scenario variable
    }

    @Before
    public void sessionIn(Scenario scenario) {
        String scenarioName = scenario.getName().replaceAll(" ", "_");
        String fileName = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyyMMddhhmmss"));

        try {
            printStream = new PrintStream("target/runLogs/" + scenarioName + "_" + fileName + ".txt");
        } catch (FileNotFoundException e) {
            throw new RuntimeException("Unable to create log file: " + e.getMessage());
        }

        logInfo("//===============Session In=======================//\n");
        logInfo("Test Execution started at " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss")));
        logInfo("Scenario '" + scenario.getName() + "' is executing..");
    }

    @After
    public void sessionOut(Scenario scenario) {
        boolean failed = scenario.isFailed();
        logInfo(failed ? "^^^^Test completed with failures - check report for failure^^^^" : "^^^^Test successfully completed^^^^");
        logInfo("Test Execution Completed at " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss")) + "\n");
        logInfo("//===============Session Out=======================//\n\n");
        if (printStream != null) {
            printStream.close();
        }
    }

    @AfterStep
    public void afterScenario(final Scenario scenario) {
        if (getDriver() != null) {
           try {
                if (scenario.isFailed())
                {
                    byte[] screenshot = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.BYTES);
                    scenario.attach(screenshot, "image/png", "Failed Screenshot");
                   
              }
            } catch (Exception e) {
                logError("Error taking screenshot: " + e.getMessage());
            }
        }
    }
    @After
    public void tearDown() {
    	ExcelReaderandwrite.stopWorker();
    }
}
